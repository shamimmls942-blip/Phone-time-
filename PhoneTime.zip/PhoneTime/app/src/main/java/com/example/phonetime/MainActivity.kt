package com.example.phonetime

import android.app.Activity
import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.*

class MainActivity : Activity() {

    private lateinit var root: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() { render(); handler.postDelayed(this, 60_000) }
    }
    private var shareText = ""

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        val sv = ScrollView(this).apply { setBackgroundColor(BG) }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(40), dp(16), dp(32))
        }
        sv.addView(root)
        setContentView(sv)
    }

    override fun onResume() { super.onResume(); handler.post(ticker) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(ticker) }

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bn(s: String) = s.map { if (it in '0'..'9') '০' + (it - '0') else it }.joinToString("")
    private fun num(n: Long) = bn(String.format(Locale.US, "%,d", n))
    private fun dur(ms: Long): String {
        val h = ms / 3_600_000; val m = (ms / 60_000) % 60
        return if (h > 0) "${num(h)} ঘণ্টা ${num(m)} মিনিট" else "${num(m)} মিনিট"
    }

    private fun tv(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = t; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setLineSpacing(0f, 1.2f)
        }

    private fun card(color: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(22), dp(20), dp(22), dp(20))
        background = GradientDrawable().apply { setColor(color); cornerRadius = dp(28).toFloat() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) }
    }

    // ---------- usage ----------
    private fun hasPermission(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29)
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        else @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private class Usage(val total: Long, val perApp: Map<String, Long>)

    private fun usage(start: Long, endIn: Long): Usage {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = minOf(endIn, System.currentTimeMillis())
        if (end <= start) return Usage(0, emptyMap())
        val ev = usm.queryEvents(start, end)
        val e = UsageEvents.Event()
        val open = HashMap<String, Long>()
        val per = HashMap<String, Long>()
        var total = 0L
        fun close(pkg: String, st: Long, at: Long) {
            val d = (at - st).coerceAtLeast(0)
            per[pkg] = (per[pkg] ?: 0) + d; total += d
        }
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            val p = e.packageName ?: continue
            when (e.eventType) {
                1 -> if (!open.containsKey(p)) open[p] = e.timeStamp          // resumed
                2 -> { val st = open.remove(p) ?: start; close(p, st, e.timeStamp) } // paused
                16, 26 -> { open.entries.toList().forEach { close(it.key, it.value, e.timeStamp) }; open.clear() } // screen off / shutdown
            }
        }
        open.forEach { close(it.key, it.value, end) }
        return Usage(total, per)
    }

    private fun midnight(daysAgo: Int): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        c.add(Calendar.DAY_OF_YEAR, -daysAgo)
        return c.timeInMillis
    }

    private fun label(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) { pkg }

    // ---------- UI ----------
    private fun render() {
        root.removeAllViews()
        root.addView(tv("📱 ফোনের পেছনে কত সময়?", 22f, Color.WHITE, true).apply { setPadding(0, 0, 0, dp(16)) })

        if (!hasPermission()) {
            val c = card(PURPLE)
            c.addView(tv("শুরু করতে অনুমতি দিন", 20f, Color.WHITE, true))
            c.addView(tv("সঠিক স্ক্রিন টাইম দেখাতে ‘Usage access’ অনুমতি লাগবে। শুধু আপনার ফোনেই থাকবে, কোথাও পাঠানো হয় না।", 15f, 0xFFDDD6F5.toInt()).apply { setPadding(0, dp(8), 0, dp(12)) })
            c.addView(Button(this).apply {
                text = "অনুমতি দিন"
                setOnClickListener { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
            })
            root.addView(c); return
        }

        val now = System.currentTimeMillis()
        val today = usage(midnight(0), now)
        var week = today.total
        val weekApps = HashMap<String, Long>(today.perApp)
        var pastTotal = 0L; var pastDays = 0
        for (i in 1..6) {
            val u = usage(midnight(i), midnight(i - 1))
            week += u.total; pastTotal += u.total
            if (u.total > 60_000) pastDays++
            u.perApp.forEach { (k, v) -> weekApps[k] = (weekApps[k] ?: 0) + v }
        }
        val avgMs = if (pastDays > 0) pastTotal / pastDays else today.total
        val daysCounted = if (pastDays > 0) pastDays else 1

        // Card 1: today
        val c1 = card(0xFF2B5D8A.toInt())
        c1.addView(tv("আজকের স্ক্রিন টাইম", 15f, 0xFFD6E6F5.toInt()))
        c1.addView(tv(dur(today.total), 30f, Color.WHITE, true))
        root.addView(c1)

        // Card 2: 7 days
        val c2 = card(0xFF2E6B57.toInt())
        c2.addView(tv("গত ৭ দিনের স্ক্রিন টাইম", 15f, 0xFFD3F0E3.toInt()))
        c2.addView(tv(dur(week), 30f, Color.WHITE, true))
        c2.addView(tv("দিনে গড়ে ${dur(avgMs)}", 14f, 0xFFD3F0E3.toInt()).apply { setPadding(0, dp(4), 0, 0) })
        root.addView(c2)

        // Projection: 5 years at this pace
        val hours = (avgMs / 3_600_000.0 * 365 * 5).toLong()
        val days = hours / 24
        val months = days / 30
        val c3 = card(PURPLE)
        c3.addView(tv("এই অভ্যাসে ৫ বছরে আপনি ফোনে ব্যয় করবেন", 16f, 0xFFE4DDF7.toInt()))
        c3.addView(tv("${num(hours)} ঘণ্টা", 40f, Color.WHITE, true))
        c3.addView(tv("অর্থাৎ", 15f, 0xFFE4DDF7.toInt()))
        c3.addView(tv("${num(days)} দিন", 40f, Color.WHITE, true))
        c3.addView(tv("≈ ${num(months)} মাস দিনরাত একটানা ফোনে!", 14f, 0xFFE4DDF7.toInt()).apply { setPadding(0, dp(6), 0, 0) })
        root.addView(c3)

        // Seeded randomness: different per person, changes daily
        val doy = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        val rnd = Random(hours * 31 + doy)
        val topPkg = weekApps.maxByOrNull { it.value }?.key
        val topApp = if (topPkg != null) label(topPkg) else "ফোন"
        val km = hours * 5

        // Fun card
        val funs = listOf(
            "😂 ${num(hours)} ঘণ্টা ঘুড়ি উড়ালে পাড়ার সব ঘুড়ির প্যাঁচ কাটা পড়ত — আপনি হতেন ‘বো-কাট্টা’ সম্রাট!",
            "🤳 $topApp যদি বেতন দিত, এতদিনে আপনি তার সেরা কর্মচারী হতেন!",
            "🐢 এই সময়ে একটা কচ্ছপ ${num((hours * 0.3).toLong())} কিমি হেঁটে ফেলত — আর আপনার আঙুল? শুধু স্ক্রল!",
            "🍚 ${num(hours)} বার গরম ভাত খেতে পারতেন — অথচ ভাত ঠান্ডা হয়েছে $topApp-এ!",
            "👆 আপনার বুড়ো আঙুলের ওভারটাইম পাওনা হয়ে গেছে — দাবি তুললে কী হবে!",
            "📞 $topApp আপনাকে এতটাই চেনে, যতটা আপনার বন্ধুও চেনে না!"
        )
        val c4 = card(0xFF6B3A47.toInt())
        c4.addView(tv(funs[rnd.nextInt(funs.size)], 17f))
        root.addView(c4)

        // What you could have done
        class Act(val v: Double, val t: (Long) -> String)
        val h = hours.toDouble()
        val acts = listOf(
            Act(h / 6) { "📚 ${num(it)} টি বই পড়ে শেষ করতে পারতেন" },
            Act(h / 2.2) { "🎬 ${num(it)} টি সিনেমা দেখতে পারতেন (পপকর্নসহ!)" },
            Act(h / 600) { "🗣️ ${num(it)} টি নতুন ভাষার বেসিক শিখে ফেলতে পারতেন" },
            Act(h / 10) { "✈️ ঢাকা–লন্ডন ফ্লাইটে ${num(it)} বার যাওয়া-আসা করতে পারতেন" },
            Act(h * 5 / 400) { "🚶 হেঁটে ঢাকা থেকে কক্সবাজার ${num(it)} বার যেতে পারতেন" },
            Act(h / 8) { "😴 ${num(it)} রাত পুরো ৮ ঘণ্টা শান্তির ঘুম দিতে পারতেন" },
            Act(h / 300) { "💻 ${num(it)} টি পূর্ণাঙ্গ অনলাইন কোর্স শেষ করতে পারতেন" },
            Act(h / 1.5) { "🍳 ${num(it)} বার নতুন রেসিপি রান্না করতে পারতেন" },
            Act(h * 200 / 1000) { "💰 ঘণ্টায় ২০০ টাকা আয় করলেও ৳${num(it * 1000)} জমাতে পারতেন" },
            Act(h / 1000) { "🎸 গিটারে প্রো-লেভেলের ১,০০০ ঘণ্টা প্র্যাকটিস ${num(it)} বার করতে পারতেন" },
            Act(h / 100) { "🏃 ${num(it)} টি ৫ কিমি দৌড়ের ট্রেনিং প্ল্যান সম্পূর্ণ করতে পারতেন" }
        ).filter { it.v >= 1 }.shuffled(rnd).take(5)

        val c5 = card(0xFF1E1B24.toInt())
        c5.addView(tv("এই সময়ে আপনি যা করতে পারতেন", 17f, Color.WHITE, true).apply { setPadding(0, 0, 0, dp(8)) })
        val lines = acts.map { it.t(it.v.toLong()) }
        lines.forEach { c5.addView(tv(it, 15f, 0xFFE6E1EE.toInt()).apply { setPadding(0, dp(6), 0, dp(6)) }) }
        root.addView(c5)

        shareText = "📱 আমি আজ ${dur(today.total)} ফোন চালিয়েছি, গত ৭ দিনে ${dur(week)}!\n" +
            "এই অভ্যাসে ৫ বছরে ${num(hours)} ঘণ্টা (${num(days)} দিন) ফোনে যাবে 😱\n" + lines.joinToString("\n")

        val share = Button(this).apply {
            text = "বন্ধুদের সাথে শেয়ার করুন"
            isAllCaps = false; setTextColor(0xFFD9C8FF.toInt())
            background = GradientDrawable().apply { setColor(Color.TRANSPARENT); setStroke(dp(1), 0xFFB9A2F0.toInt()); cornerRadius = dp(30).toFloat() }
            setOnClickListener {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, shareText) }, "শেয়ার"))
            }
        }
        root.addView(share, LinearLayout.LayoutParams(-1, dp(54)))
    }

    companion object {
        const val BG = 0xFF121014.toInt()
        const val PURPLE = 0xFF4E3A8E.toInt()
    }
}
